package com.example.trabajo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoApplicationTests {

	@Test
	void contextLoads() {
	}

}
